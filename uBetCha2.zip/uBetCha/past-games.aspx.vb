﻿
Partial Class past_games
    Inherits System.Web.UI.Page

End Class
