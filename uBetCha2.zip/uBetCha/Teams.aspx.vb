﻿
Partial Class Teams
    Inherits System.Web.UI.Page

End Class
