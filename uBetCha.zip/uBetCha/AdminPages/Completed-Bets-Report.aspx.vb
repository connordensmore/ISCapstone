﻿
Partial Class AdminPages_Completed_Bets_Report
    Inherits System.Web.UI.Page

End Class
