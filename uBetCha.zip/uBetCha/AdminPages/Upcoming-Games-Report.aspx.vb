﻿
Partial Class AdminPages_Upcoming_Games_Report
    Inherits System.Web.UI.Page

End Class
