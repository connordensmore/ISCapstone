﻿
Partial Class AdminPages_Upcoming_Bets_Report
    Inherits System.Web.UI.Page

End Class
