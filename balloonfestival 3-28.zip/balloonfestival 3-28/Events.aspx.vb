﻿
Partial Class Events
    Inherits System.Web.UI.Page

End Class
