﻿
Partial Class Retrieve
    Inherits System.Web.UI.Page
    Dim cn As New Data.SqlClient.SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Balloon.mdf;Integrated Security=True")
    Protected Sub btnRetrieveID_Click(sender As Object, e As EventArgs) Handles btnRetrieveID.Click
        txtRetrieveId.Text = ddlgetid.SelectedValue.ToString()
        Dim str As String = "Select * from Balloons where Balloons_id =" & txtRetrieveId.Text
        Dim cmd As New Data.SqlClient.SqlCommand(str, cn)
        cmd.Connection = cn
        cn.Open()

        Dim dr As Data.SqlClient.SqlDataReader = cmd.ExecuteReader


        While (dr.Read())
            txtBallonID.Text = dr("Balloons_id").ToString()
            txtBalloonName.Text = dr("Balloon_Name").ToString()
            txtBallonDesc.Text = dr("Balloon_Desc").ToString()
        End While
        dr.Close()
        cn.Close()

    End Sub
End Class
