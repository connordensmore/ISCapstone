﻿
Partial Class Balloons
    Inherits System.Web.UI.Page
    Dim cn As New Data.SqlClient.SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Balloon.mdf;Integrated Security=True")
    Protected Sub btnAddBalloon_Click(sender As Object, e As EventArgs) Handles btnAddBalloon.Click
        cn.Open()

        Dim cmd As New Data.SqlClient.SqlCommand(("Insert INTO Balloons (Balloon_Name, Balloon_Desc, Balloon_Image, Balloon_Pilot, Homeplace) VALUES ('" & txtBalloonName.Text & "', '" & txtBalloonDesc.Text & "', '" & txtImage.Text & "', '" & dblPilot.Text & "', '" & txtHomeLocation.Text & "')"), cn)

        cmd.ExecuteNonQuery()
        cn.Close()

        lblMessage.Text = txtBalloonName.Text & " " & " has been added!"

        txtBalloonName.Text = ""
        txtBalloonDesc.Text = ""
        txtImage.Text = ""
        txtHomeLocation.Text = ""
        dblPilot.SelectedIndex = 0
        txtBalloonName.Focus()

        GridView1.DataBind()


    End Sub
End Class
