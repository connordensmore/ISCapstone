﻿
Partial Class Reviews
    Inherits System.Web.UI.Page
    Dim cn As New Data.SqlClient.SqlConnection("Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\Balloon.mdf;Integrated Security=True")

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Review_btn.Click
        cn.Open()

        Dim cmd As New Data.SqlClient.SqlCommand(("INSERT INTO Reviews (Review_id, Customer_Name, Date_of_Review, Review) VALUES ('" & Review_id.Text & "', '" & Customer_Name.Text & "','" & Date_of_Review.Text & "', '" & Review.Text & "')"), cn)
        cmd.ExecuteNonQuery()
        cn.Close()

        Review_msg.Text = "Your review has been added! Thanks!"
        Review_id.Text = ""
        Customer_Name.Text = ""
        Date_of_Review.Text = ""
        Review.Text = ""
        ddlEvents.SelectedIndex = 0



    End Sub
    Protected Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        Review_id.Text = ""
        Customer_Name.Text = ""
        Date_of_Review.Text = ""
        Review.Text = ""
        Review_msg.Text = ""
    End Sub
End Class
