INSERT INTO Events(Event_Name,Event_Desc,Event_Date,Event_Location,Fees) VALUES ('Marvy''s Balloon Magic','Low Country Fair Balloon Event','2/1/2021','Florida',300);
INSERT INTO Events(Event_Name,Event_Desc,Event_Date,Event_Location,Fees) VALUES ('Balloon International','Community Sponsored Balloon festival','7/11/2021','Nevada',300);
INSERT INTO Events(Event_Name,Event_Desc,Event_Date,Event_Location,Fees) VALUES ('Virgina Balloon Festival','30 balloons flyinand flyout','12/1/2020','Virginia',150);
INSERT INTO Events(Event_Name,Event_Desc,Event_Date,Event_Location,Fees) VALUES ('International Balloon Festival','1000 balloon event','10/15/2021','Georgia',450);
